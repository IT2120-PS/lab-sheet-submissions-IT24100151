getwd()
setwd("C:\\Users\\it24100151\\Desktop\\IT24100151")
getwd()

#1. Import the dataset (’Exercise.txt’) into R and store it in a data frame called ”branch data”
branch_data <- read.table("Exercise.txt" , header = TRUE, sep = ",")
head(branch_data)

#2. Identify the variable type and scale of measurement for each variable.
# Branch - Categorical (Nominal Scale)
# Sales_X1 - Continuous (Ratio Scale)
# Advertising_X2 - Continuous (Ratio Scale)
# Years_X3 - Discrete (Ratio Scale)

#3. Obtain boxplot for sales and interpret the shape of the sales distribution.
boxplot(branch_data$Sales_X1,main = "Boxplot of sales" , horizontal = TRUE)

#4. Calculate the five number summary and IQR for advertising variable.
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#5. Write an R function to find the outliers in a numeric vector and check for outliers in years variables.
get_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3-q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  outliers <-  x[x < lb | x > ub]
  return(outliers)
}

get_outliers(branch_data$Years_X3)
