getwd()
setwd("C:\\Users\\senur\\OneDrive - Sri Lanka Institute of Information Technology\\Y2S1\\IT24100151")
getwd()

# Exercise
# i. State the null and alternative hypotheses for the test.
# ii. Perform a suitable chi-squared test to test the null hypothesis.
# iii. Give your conclusions based on the results.


file.path <- "C:\\Users\\senur\\OneDrive - Sri Lanka Institute of Information Technology\\Y2S1\\IT24100151\\Data.csv"
data <- read.csv(file.path)
head(data)

# Chi-squared goodness of fit test

# Observed counts
housetasks <- c(120, 95, 85, 100)

# Expected probabilities (equal for each snack)
expected_probs <- c(0.25, 0.25, 0.25, 0.25)

# Perform chi-square test
chisq_test <- chisq.test(housetasks, p = expected_probs)

# Display results
chisq_test


# Conclusion:
# There is no significant evidence to suggest that customers have different preferences among the four snack types (A, B, C, and D).
# Therefore, the data supports the vending machine owner’s claim that all snack types are chosen equally often.
